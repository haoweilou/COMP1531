1.Demonstration of an understanding of the need for software verification and validation

         Verification of the software basically means if the software has been built right or in other words, if the software is bug-free.

        Validation of the software means the right software has been built in the way it&#39;s meant to be built. So it must be more than bug-free, it also should meet the requirement.

        For our program, we&#39;ve applied multiple test to ensure its verification and validation.

—Unit-testing

        We have designed tests from iteration 1 for each function so that for this stage we just imply these pytest as a primary test. In these test, we test our functions&#39;s basic verification and validation.

        Such as, the pytest is supposed to test the exceptions and Errors mentioned in spec, these test proves when invalid input is used, bugs can be detected. Hence the verification of our program can be proven.

        Also our pytest test the consequence of our functions. We are not only testing the correctness of the function itself as well as if good effect is made. Such as, user\_profile is used to prove that function auth\_login is correctly built. So that we can make sure our function achieves what we want them to achieve.

        We have multiple Unit-testing for every signal function we written, these white-test ensure the each individual software component is verified and valid.

—Integration Testing

        As we have already mentioned, some other functions are compulsory to test a specific function. Such as for testing the admin\_permission\_change function, a series of functions are required to provide the convincing testing result.

        We are doing integration testing as white tests not only in pytest and also in postman and these tests are proving a further verification and validation to our functions.

—System testing

        Instead of integrating all the function in a main functions and run a general pytest, we just directly test our program in the front end and test if it meets the initial requirement.

        This test is the most important test, because it directly determine if our program is successfully built. And if it fails in this stage, it means we need to go back to our initial code and user story, and test them from pytest / postman again.

—Acceptance testing

        Since the front-end is not built by us, so it&#39;s kinds of meaningless to do a acceptance testing. But we did do some white test, the all of the testers agree the front-end is technically bug-free and working well.



        There are a few examples showing how we designing our test, from user story and extract the acceptance criteria. Then we edit our pytest from iteration one, check if it considers all the situations. Then we test them in postman and ultimately test it in front-end.



2. Development of appropriate acceptance criteria based on user stories and requirements.

US1: As a user, I want to log in my account, so that I can access my own account by password and username by (any device)

—The user navigates to the login page and fills up the &quot;email&quot; and &quot;password&quot; field with correct details

—user clicks the &quot;Sign in&quot; button then the user will be successfully signed in and be able to view the internal interface

—If the password is incorrect, an error message will pop-up to notify the user to retry

—If the email is in a valid format, an error message will pop-up to notify the user the email is not in correct format

—If the email is notbelonging to any users, an error message will pop-up to notify the user the email is not belonging to anyone



US2: As a user, I want to register, so that I can create a account (to store my personal information and records)

—The user navigates to the login page and select &quot;Register&quot; option

—The web page refresh to register page

—The user fills up the &quot;email&quot;, &quot;password&quot;, &quot;first name&quot;, &quot;last name&quot; field in correct format

—User clicks the &quot;submit&quot; button

—User has been successfully registered and refreshed to internal interface

—If the password is incorrect, an error message will pop-up to notify the user to retry

—If the email is in a valid format, an error message will pop-up to notify the user the email is not in correct format

—If the email is notbelonging to any users, an error message will pop-up to notify the user the email is not belonging to anyone

—If the user name is in a valid format, an error message will pop-up to notify the user to retry

US3: As a user, I want to log out, so that my personal account (would not be used by other users)

—The user navigates to the user interface

—Userselect &quot;Log out&quot; option and confirm

—The web page refreshes to home page and the user successfully signed out

US4: As a user, I want to reset password through my email, so that I can change me password in case I forget my (previous) password  or for security purpose

—The user has navigated to the login page andselect &quot;forgot password&quot; button

—Entered a valid email to receive a link for password recovery

—The system sent the link to the entered email

—The user received the link via the email and navigate through the link received in the email

—The system enables the user to set a new password

—If a non-existing email is input in requisition function, secret code will be not sent.

—If the new password is not in correct format, an error message will pop-up to notify the user to retry

—If the secret code is not correct, an error message will pop-up to notify the user to retry

US5: As a user, I want to see thelist of channels that I&#39;ve joined) so that I can receive and send message in these channels

—The user has navigated to the home page and select the &quot;my channels&quot; option

—The dialog has been appeared in the middle of page with list of joined channels



US6: As a user, I want to see the entire list of channels, so that I can find the channels (I&#39;m interested but currently not belonging to)

—The usernavigates to the home page and the user select the &quot;All channels&quot; option

—A dialog has been appeared in the middle of page with the list of all channels

—Private channels wouldn&#39;t be shown in detail

US7: As a user, I want to create my own channel, so that I can start up a channel for a specific purpose and i can (manage it by myself)

—The user select &quot;create channel&quot; and  fills the channel name correctly(less than 20 character)

—The user chooses if he want the channel to be public

—the user click the button &quot;submit&quot; in the dialog

—A flash message &quot;your channel has been successfully created&quot; has been shown

US8:As a user, I want to join channels, so that I can communicate with the people who have a shared interest with me

—The user has navigated to the home page and select the &quot;All channels&quot; option

—The list of all channels is shown in dialog

—The user click the &quot;join this channel&quot; next to the a certain channel description (user is currently not a member of them)

—A flash message of &quot;you have successfully joined xxx&quot; (xxx is the channel name you chosen)



US9:As a user, I want to invite someone to join a channel, so that we can communicate (interactively) in group

—The user has navigated to another user&#39;s profile page

—The user select &quot;invite to my channels&quot;

—The list of the user channel has been displayed

—Choose the channel the user want to invite to (the other user is not member of them)

—The user confirms the invitation and the invitation is succeed

—If the channel\_id is not existing, an error message will pop-up to notify the user the channel\_id doesn&#39;t exist

—If the user\_id is not existing, an error message will pop-up to notify the user the user\_id doesn&#39;t exist

—If the user is not a member in the channel, an error message will pop-up to notify the user the user is not a member in the channel



US10:As a user, I want to leave the channel, so that I can stop (receiving message) from the channel that I&#39;m not interested any more



—User can only request to leave a channel that they are originally a member of

—User can only leave a channel that exists on their Slackr app

—User will be removed from the channel immediately.

—User handle will be immediately unauthorised to perform basic functions that a member of a channel are usually able to

—There will be a button on the side bar with the placeholder &quot;Leave Channel&quot; if the user is currently in a channel. Clicking the button will result in a confirmation pop up box with buttons with placeholders displaying &quot;Yes&quot; and &quot;No&quot;. If &quot;Yes&quot; is clicked, the user will leave the channel.

—The button will then disappear.



US11: As a user, I want to view all messages in the channels so that I can what other members express when i was not active in the channel

—The user has navigated to the channel page and chatting interface is shown with all the joined channels

—The user click the icon of one of his channels and the entire chatting record will be shown on the interface

—The message string, sender and time sent are all displayed to user

—more hidden chatting recording will be displayed

—The notification will be canceled when all the chatting recordings are viewed



US12: As a user, I want to view all members and owner in channels, so that I can be aware of who exactly are currently in the channel

—the user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user click the button &quot;View all the members&quot;

—A dialog has been appeared in the middle of page

—The list of members&#39; user name has been shown in the dialog

—The owner of this channel will be highlighted in the dialog



US13: As a user, I want to send message in the channel so that other member can view my message immediately and response to it

—User requesting to view channel messages must be at least a member of the channel

Returns a maximum of 50 messages for the user to view

—Function returns a new index &quot;end&quot; which is the value of &quot;start + 50&quot;, with the start index specified by the user

—If the most recent function is returned, then the &quot;end&quot; value is &quot;-1&quot;

—After 50 messages have been displayed, the user can view more messages by scrolling up, which will trigger 50 more messages to be loaded.

US14: As a user, I want to add another owner in my channel so that we can manager the channel together

—Only an owner of the channel can add other owners

—User must be a member of the channel before they can be added as an owner

—You cannot attempt to perform this function on a user that is already the channel owner

—The channel that the user is attempting to remove owner from must be a valid channel that exists on their Slackr app



US15: As a user, I want to send a message in specific time, so that I can pre-edit my message and other members can receive message in the time I want

—The user navigates to the user interface andselect the &quot;All channels&quot; option

—The list of all channels is shown

—The user click the &quot;join this channel&quot; next to the a certain channel description (user is currently not a member of them)

—A flash message of &quot;you have successfully joined xxx&quot; (xxx is the channel name you chosen)



US16: As a user, I want to edit message so that I can update the text and add additional information to my previous message

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user select the icon of one of his channels

—The user right-click a message that sent by him

—click the option &quot;edit my text&quot;

—the text field will be open to re-edit

—The user filled the text field (less than 1000 characters)

—The user press return key for confirmation

—the edit text will be displayed in the chatting record instead of previous one



 US17: As a user, I want to remove a message so that others won&#39;t be able to view the message if I don&#39;t want to send

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user right-click a message that sent by him

—click the option &quot;remove my message&quot;

—the message will be disappeared in the chatting record



US18: As a user, I want to pin a message to the top, so that I can highlight the important message for emphasising purpose

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user right-click a message

—click the option &quot;Pin the massage&quot;

—the message will be displayed on the top channel regardless sliding the page

US19: As a user, I want to unpin a message so that I can renew the message status if I don&#39;t want my pinned message to remain on the top anymore

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user right-click a pinned message on the top of channel(pinned by himself )

—click the option &quot;Unpin the massage&quot;

—the message will be no longer displayed on the top channel



US20: As a user, I want to react a message so that I can stress my feeling on a particular message

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user right-click a message

—click the one of the emoji option

—the emoji will be displayed next to the message with user&#39;s name



US21: As a user, I want to unreact a message so that I can remove my previous feedback from a messages when it is not appropriate anymore

—The user has navigated to the channel page

—chatting interface is shown with all the joined channels

—The user click the icon of one of his channels

—The user right-click a message (he reacted before)

—click the one of the emoji option that he has chosen

—the emoji and user&#39;s name will be not displayed next to the message anymore

US22: As a user, I want to view other users profile so that I can obtain the name and email detail from the user I&#39;m interested

—Users must be part of the channel in order to request to view it&#39;s details

—Users must request for a valid channel that exists on Slack

—Pressing the channel details button will show the basic details of the channel including —The channel name, as well as all members in the channel. Owners of the channel are also explicitly flagged.

—There will be a button on the side bar with the place holder &quot;Details&quot;

—When clicked, the details will be shown in a pop up box with another button in the top —Right corner with a placeholder &quot;x&quot; that will close the details when clicked.



US23: As a user, I want to modify my own profile so that I can renew my previous personal details

—The user has navigated to the home page

—The user clicks the icon of his profile photo

—The user click the button &quot;update profile&quot;

—A dialog has been appeared in the middle of page

—You correctly fill the handle name, email address (valid address and handle name need to be less than 20 characters)

—Upload a profile photo in valid format

—click the &quot;submit&quot; bottom

—a flash message is shown &quot;all the personal informations have been updated&quot;



US23: As a user, I want to search a message by a search string, so that I can view all the related messages in message log

—If there are no matched string in all of the message lists of channels that the user joined, there are still no errors been reported

—The user must be a part of at least one channel as an authorised user

—Search() will only searching the query string from the channels that the user has joined

—The query string can not be longer than 1000 characters

—There will be a textbox in the top bar with the place holder &quot;Search&quot;. When the user clicks on the textbox, the place holder will disappear.

—The user can type in a string. After pressing the button next to the search bar, a list will be shown with all instances of that string displayed.

US24: As a administrator, I want to modify users&#39; admin privileges so that I can classify users into different privileges to lend a assist my management

—The administrator navigates in the management page select &quot;Privileges management&quot;

—The administrator click the &quot;change privilege &quot; button next to a member&#39;s name

—The page refreshes

—A flash message &quot;User xxx is a administrator&quot; is shown

US25:As a user, I want to use the &#39;stand up&#39; function so that some important conversations would be able to be recorded and organised by the attenders

—The user navigated to the channel page

—The user click the &quot;start a standup &quot; button

—A notification is sent in the chatting record

—A 15 minutes countdown is shown in the chatting interface

—A 15 minutes period reached

—All the messages sent by group members in the past 15 minutes are arranged and organised

—The summary of these chatting record is sent in the channel

3.Demonstration of appropriate tool usage for assurance (code coverage, linting, etc.)

Coverage:

We have test all the pytest, they are with test coverage 100% except 3 of them are 95%

Linting:

We improve our mark from 3.8 to 5 by using it

Postman:

Postman is used for testing before the front end is released

Front end provided by school:

They are the place we start the system test.



4. Examples of how we go though the tests

Function name: auth\_login



User story: As a user, I want to log in my account, so that I can access my own account by password and username in any device.



User acceptance criteria:

—The user navigates to the login page and fills up the &quot;email&quot; and &quot;password&quot; field with correct details

—user clicks the &quot;Sign in&quot; button then the user will be successfully signed in and be able to view the internal interface

—If the password is incorrect, an error message will pop-up to notify the user to retry

—If the email is in a valid format, an error message will pop-up to notify the user the email is not in correct format

—If the email is notbelonging to any users, an error message will pop-up to notify the user the email is not belonging to anyone



Strategy to Test Function:

Main idea:

        Once the function is preformed, a dictionary containing user\_id and token will be return. By checking the correctness of the returned items and also if they are returned, we can deduce the authentication and validation of the function. Additionally, all the errors and exceptions should be considered.



Pytest:

— input an invalid email to test if the function return a ValueError

— input an invalid password(more than 5 characters) to test if the function return a ValueError

— input an email that hasn&#39;t been registered to test if the function return a ValueError

— Register a user and get their token and u\_id by auth\_login,  then use them as parameter to call user\_profile function. If the token is valid, the user\_profile function should be successfully called. If the u\_id is correct, the user\_profile should display the details we just registered.



Postman:

—check if the function returns a token and user id if we input a valid password and registered email. (the validation of the items returned is already verified in Pytest)



Frontend:

We connect to the front page to see if a registered user can login.

































Function: auth\_logout



User stories: As a user, I want to log out, so that my personal account would not be used by other users.



User Acceptance Criteria:

—The user navigates to the user interface

—Userselect &quot;Log out&quot; option and confirm

—The web page refreshes to home page and the user successfully signed out



Strategy to Test Function:

Main idea:

        If the function is successful performed, then the flag &quot;active&quot; of the user will be False and function should return a dictionary containing the key called &quot;is\_success&quot; which is True.



Pytest:

—When user loggedout, test if function return {&quot;is\_success&quot;: True}

—After user loggedout, test if the &quot;active&quot; key in user&#39;s dictionary is False

Postman:

—check if the function returns correct data structure of data if we logged the user out.

Frontend:

We logged in by valid password and email, then logged out to checkif any error occur. Then test if we return to the front page from internal interface.



















Function name: auth\_register



User story:  As a user, I want to register, so that I can create an account to store my personal information and records

User acceptance criteria:

—The user navigates to the login page and select &quot;Register&quot; option

—The web page refresh to register page

—The user fills up the &quot;email&quot;, &quot;password&quot;, &quot;first name&quot;, &quot;last name&quot; field in correct format

—User clicks the &quot;submit&quot; button

—User has been successfully registered and refreshed to internal interface

—If the password is incorrect, an error message will pop-up to notify the user to retry

—If the email is in a valid format, an error message will pop-up to notify the user the email is not in correct format

—If the email is notbelonging to any users, an error message will pop-up to notify the user the email is not belonging to anyone

—If the user name is in a valid format, an error message will pop-up to notify the user to retry

Strategy to Test Function:

Main idea:

        Once the function is preformed, a dictionary containing user\_id and token will be return. By checking the correctness of the returned items and also if they are returned, we can deduce the authentication and validation of the function. Additionally, all the errors and exceptions should be considered.

        The information about the user in the global variable &quot;data&quot; should be renewed after the function



Pytest:

— input an invalid email to test if the function return a ValueError

— input a registered email to test if the function return a ValueError

— input an invalid password to test if the function return a ValueError

— input an invalid first name to test if the function return a ValueError (longer than 50 character)

— input an invalid last name to test if the function return a ValueError (longer than 50 character)

— input an invalid last and first name to test if the function return a ValueError (both longer than 50 character)

—repeated name should not influence the operation of the fucntion

—Register a user and get their token and u\_id then use them as parameter to call user\_profile function. If the token is valid, the user\_profile function should be successfully called. If the u\_id is correct, the user\_profile should display the details we just registered.

Postman:

—check if the function returns a token and user id if we input a valid password and registered email. (the validation of the items returned is already verified in Pytest)

Frontend:

—We connect to the front page to see if we can successfully register. Then check if we can successfully check other functions like user\_profiles













































Function: auth\_passwordreset\_request / auth\_passwordreset\_reset



User stories: As a user, I want to reset password through my email, so that I can change me password in case I forget my previous password or for security purpose.



User Acceptance Criteria:

—The user has navigated to the login page andselect &quot;forgot password&quot; button

—Entered a valid email to receive a link for password recovery

—The system sent the link to the entered email

—The user received the link via the email and navigate through the link received in the email

—The system enables the user to set a new password

—If a non-existing email is input in requisition function, secret code will be not sent.

—If the new password is not in correct format, an error message will pop-up to notify the user to retry

—If the secret code is not correct, an error message will pop-up to notify the user to retry



Strategy to Test Function:

Main idea:

        When the request function is call, a random 6-digit number will be sent to the email and the 6 digit number will be the return of the request function. The secret code will also be added in global variable &quot;data&quot;

        Then in reset function, if the password is in correct format and secret code is correct, the password should be updated.



Pytest:

—input an invalid email in request function  to test if the function return None

—input an valid email in request function to test if the function return a six digit code

—input an incorrect secret code in reset function to test if the function return ValueError

—input an invalid password in reset function to test if the function return ValueError

—With correct 6 digit call, the password is changed correctly and can be login with new password.



Postman:

Call the function then use the reset code from email to change the password to test if it&#39;s successful

Frontpage:

        Click on forget the password and test if we can use the reset code sent to change password







Function: channel\_invite

User stories:As a user, I want to invite someone to join a channel, so that we can communicate interactively in group



User Acceptance Criteria:

—The user has navigated to another user&#39;s profile page

—The user select &quot;invite to my channels&quot;

—The list of the user channel has been displayed

—Choose the channel the user want to invite to (the other user is not member of them)

—The user confirms the invitation and the invitation is succeed

—If the channel\_id is not existing, an error message will pop-up to notify the user the channel\_id doesn&#39;t exist

—If the user\_id is not existing, an error message will pop-up to notify the user the user\_id doesn&#39;t exist

—If the user is not a member in the channel, an error message will pop-up to notify the user the user is not a member in the channel



Strategy to Test Function:

        Invites a user (with user id u\_id) to join a channel with ID channel\_id. Once invited the user is added to the channel immediately. If all the parameters are in correctly format, then it should return empty dictionary.

Pytest:

—Make a user who is not in the channel invite other people to this channel to see if access error raised

—Invite a invalid user to the channel to see if value error raised

—Invite a valid user who is already in the channel to see if access error raised

—Invite a user into the channel and let this user invite another use in the channel then

—check the database to see if the change added in the database

Postman:

Invite a user into the channel and let this user invite another use in the channel then check the database to see if the change added in the database

Frontpage:

Invite another user into channel and check if they are in  the channel list.











Function: channel\_details

User stories:  As a user, I want to view all members and owner in channels, so that I can be aware of who exactly are currently in the channel



User Acceptance Criteria:

—Users must be part of the channel in order to request to view it&#39;s details

—Users must request for a valid channel that exists on Slack

—Pressing the channel details button will show the basic details of the channel including —The channel name, as well as all members in the channel. Owners of the channel are also explicitly flagged.

—There will be a button on the side bar with the place holder &quot;Details&quot;

—When clicked, the details will be shown in a pop up box with another button in the top —Right corner with a placeholder &quot;x&quot; that will close the details when clicked.

Strategy to Test Function:

        Given a Channel with ID channel\_id that the authorised user is part of, provide basic details about the channel, if all the parameters are in the correct format, the function should return a dictionary of name, owner\_members and all\_members.



Pytest:

—If a user wants to know detail of a channel he doesn&#39;t belong to, check if an access error

raised

—If the channel id doesn&#39;t refer to any existing channel, check if value error raised

Postman:

—Run function with valid input, to see if the correct return is shown on the postman

Frontpage:



Frontpage:

        Press the button for channel&#39;s detail and the correct details are shown

















Function: channel\_messages

User stories:  As a user, I want to send message in the channel so that other member can view my message immediately and response to it.

User Acceptance Criteria:

—User requesting to view channel messages must be at least a member of the channel

Returns a maximum of 50 messages for the user to view

—Function returns a new index &quot;end&quot; which is the value of &quot;start + 50&quot;, with the start index specified by the user

—If the most recent function is returned, then the &quot;end&quot; value is &quot;-1&quot;

—After 50 messages have been displayed, the user can view more messages by scrolling up, which will trigger 50 more messages to be loaded.



Strategy to Test Function:  Given a Channel with ID channel\_id that the authorised user is part of, return up to 50 messages between index &quot;start&quot; and &quot;start + 50&quot;. Message with index 0 is the most recent message in the channel. This function returns a new index &quot;end&quot; which is the value of &quot;start + 50&quot;, or, if this function has returned the least recent messages in the channel, returns -1 in &quot;end&quot; to indicate there are no more messages to load after this return. If all the parameters are in the correct format, the function should return a dictionary of name, owner\_members and all\_members.



Pytest:

—If the channel id doesn&#39;t refer to any existing channel, check if value error raised

—Send 50 messages to see if the output correct

—Send 51 messages to see if the output correct

Postman:

        Run function with valid input, to see if the correct return is shown on the postman

Frontpage:

        Login in the home page and join any channels, send message in the channels and see if it&#39;s displayed in the message record log.















Function: channel\_leave



User stories:  As a user, I want to leave the channel, so that I can stop (receiving message) from the channel that I&#39;m not interested any more.



User Acceptance Criteria:

—User can only request to leave a channel that they are originally a member of

—User can only leave a channel that exists on their Slackr app

—User will be removed from the channel immediately.

—User handle will be immediately unauthorised to perform basic functions that a member of a channel are usually able to

—There will be a button on the side bar with the placeholder &quot;Leave Channel&quot; if the user is currently in a channel. Clicking the button will result in a confirmation pop up box with buttons with placeholders displaying &quot;Yes&quot; and &quot;No&quot;. If &quot;Yes&quot; is clicked, the user will leave the channel.

—The button will then disappear.

Strategy to Test Function:  Given a channel ID, the user removed as a member of this channel. If all the parameters are in the correct format, the function should return a dictionary of name, owner\_members and all\_members.

Pytest:

—If the invalid channel\_id is input, then Value error should be raised

—If input is correct then the user should successfully exit the channels. Then if the user call other functions(eg. user\_list functions), the this channel should not be displayed in the list.

Postman:

        After the function run, go the database to see if the change added on the database

Frontpage:

        Choose to leave a channel and check if you are still in the channel list again

















Function name: search



User story: As a user, I want to search a message by a search string, so that I can view all the

related messages in message log

User acceptance criteria:

—If there are no matched string in all of the message lists of channels that the user joined, there are still no errors been reported

—The user must be a part of at least one channel as an authorised user

—Search() will only searching the query string from the channels that the user has joined

—The query string can not be longer than 1000 characters

—There will be a textbox in the top bar with the place holder &quot;Search&quot;. When the user clicks on the textbox, the place holder will disappear.

—The user can type in a string. After pressing the button next to the search bar, a list will be shown with all instances of that string displayed.



Strategy to Test Function:

Main idea:

 Once the function is preformed, a dictionary contained messages will be return. By checking the correctness of the returned items and also if they are returned, we can deduce the authentication and validation of the function.

Pytest:

— test the case that no string is the same with the query string

— test the case that only one string is the same with query string

— test the case that multiple strings are matched with query string



Postman:

—check if the function returns list of messages if we input a valid password and registered email. (the validation of the items returned is already verified in Pytest)

Frontend:

We connect to the front page to see if a user can found a string in messages that match with the query string.











Function name: admin\_userpermission\_change



User story: As a administrator, I want to modify users&#39; admin privileges so that I can classify users into different privileges to lend a assist my management.



User acceptance criteria:

—The administrator navigates in the management page select &quot;Privileges management&quot;

—The administrator click the &quot;change privilege &quot; button next to a member&#39;s name

—The page refreshes

—A flash message &quot;User xxx is a administrator&quot; is shown



Strategy to Test Function:

Main idea:

Once the function is preformed, nothing will return, and the user with the selected u\_id will be set as a new admin.



Pytest:

—If the target u\_id is already an admin the function return a ValueError

—If the permission id is bigger than 4 or smaller than 1 the function return a ValueError

—If the man want to call this function is not an owner the function return a ValueError

—When the u\_id refer to an invalid user the function return a ValueError



Postman:

—check if the permission id from one normal member has been changed after an owner call this function



Frontend:

We connect to the front page to see if the user has become a new admin.

















Function name: user\_profile\_sethandle



User story: As a user, I want to set my handle so that I can change it when I find a better one



User acceptance criteria:

—The user can only update their own handle

—The text for the new handle must between 3 and 20 characters

—The handle cannot be used by other users before

—The handle should be updated and displayed immediately and can be seen by other users

—The user click the &quot;new handle&quot; button in their profile page

—The user type in the new handle

—after this the handle will be changed



Strategy to Test Function:

Main idea:

For a user who calls this function, he can modify his handle and can update it immediately and also can be other users seen



Pytest:

—change the user&#39;s handle to see if the change had added to the profile

—change the handle as the same as another user&#39;s handle, there should raises ValueError

—change the handle to wrong length handle there will raise ValueError



Postman:

—run the function then access to user&#39;s detail to see if the change has been added successfully



Frontend:

—change the user handle to see if the change can be made successfully if the handle is not used

  by other users

—to see if it is not available to change the handle if the handle is already used by other users











Function name: user\_profile\_setemail



User story: As a user, I want to reset my email on app account so that I can change my mail address when I have a new email



User acceptance criteria:

—User can only change their own email and the email must be valid

—User can click on a button on top right to open the profile, and click the button next to the email in the profile page to reset email

—The update email will be used for the password reset etc.

Strategy to Test Function:

Main idea:

 Once the function is preformed, a dictionary containing user email, name and handle string will be returned. By checking the correctness of the returned items and also if they are returned, we can deduce the authentication and validation of the function. Additionally, all the errors and exceptions should be considered.



Pytest:

— test if it raises a valueError if the new email is not valid

— test if it raises a ValueError if the email is the same as before



Postman:

—check if the function returns a valid user profile. (the validation of the items returned is already verified in Pytest)



Frontend:

We connect to the front page to see if we can change the email of the user