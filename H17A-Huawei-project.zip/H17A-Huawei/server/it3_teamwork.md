# 1. Highlighting the time and outcome of team meetings for iteration 3

##  meeting agenda 

##  Fifteenth meeting 

    Meeting purpose: working arrangements 

    Data and time: 04/11 5pm

    location: main library 

    Attendees: all members 

    agenda items: 
            1. discuss the spec for iteration 3  
            2. construct the general plan for the project   

    meeting outcome: We decided to complete “task 1: adapt to changes in spec” as the first step in iteration 3, since we all agree that code part is the foundation of this iteration

    Below is the working arrangement we decided
    
    Joe: make the key change(standup/start takes in the standup length (in seconds) as a 			variable input + test)
    Yifei: make the change(added: GET users/all + test)
    David: make the changes(profile_img_url added to user return object & user/profiles/ uploadphoto now had to be completed + test)
    Kyle: make the change(for message/edit, if the new message is an empty string, the message is deleted)
    
##  Sixteenth meeting 
    
    Meeting purpose: Distribute the workload and responsibilities 
    
    Data and time: 05/11 night 
    
    location: CSE building 
    
    Attendees: All members 
    
    agenda items: 1. progression checking for each team member 
				2. discuss how to edit the previous test and integrate them as a new automated test

    meeting outcome: We completed the task 1 and finished the debugging part. We deicide Jinning and Yifei will be in charge of the test arrangement. 

##  Seventeenth meeting 
    
    Meeting purpose: Communication after the completion of first task
    
    Data and time: 06/11 1pm 
    
    location: Online group call 
    
    Attendees: All members 

    agenda items: 1.Peer view other’s work and edit them 
				2.general tests for the front end 
				3. Building ER graph                  

    meeting outcome: Haowei has completed task 6, which is the integration with the front end. And Joe made the first version of our er.pdf. Jinning and Yife are working on  the automated pytest.  
 
##  Eighteenth meeting 

    Meeting purpose: group coding on task 2 and promote our er diagram 

    Data and time: 08/11 night
    
    location: CSE lab 
    
    Attendees: All members 

    agenda items: 1. Solve the problems for the automated pytest collectively.

    meeting outcome: Problem: We find there raises error message “functions.ValueError: 400 Bad Requests: Email address is already being used by another user” when we combining the old tests together.
    Steps we took to solve the problem: We set up some default information as common information for all tests, by doing this, there will be no conflict with the email address

    Finally, we carried through about half of the total workload of task2


##  Nineteenth meeting 
    
    Meeting purpose: Complete task2 

    Data and time: 10/11 7pm 

    location: CSE lab 

    Attendees: All members 

    agenda items: 1.Discuss the method to upgrade the coverage of functions
    
    meeting outcome: We accomplished task2, put all tests in one file and happily made the function coverage approaching 100% 

##  Twentieth meeting 

    Meeting purpose: Completion of demonstrating software engineering design understanding 

    Data and time: 12/11 6pm 

    location: CSE lab 

    Attendees: All members 

    agenda items: 1. try to modify our code to make them more maintainable            
                  2. try to modify our code to make them easier to understand

    meeting outcome: 
    Problem: We find it is hard to find the raised error in the beginning when we modify some part of code.
    Steps to overcome it: According to KISS principle, we add some new help functions to reduce the repetition ratio in our code. By doing this, our code is much simpler and more maintainable

    By the end of this meeting, we run through one-fourth of the workload of task 4 and each member would do their own part at home

##  Twenty-first meeting 

    Meeting purpose: accomplishment of task4  

    Data and time: 14/11 night 

    location: ASB green lab 

    Attendees: All members 

    agenda items: 1. Discuss the bugs and conflicts in members’ own part
                  2.Try to merge members’ parts together 

    meeting outcome: 
    Problem: We found there were some new errors because of the combination, after detailed debugging, we found that the cause is variable name.
    Solutions to this problem: We unified the variables in our parts and always clear or reinitialize the variables after use to reduce the ratio of confliction 
    
    In the end of that night, we end the work of task 4  

##  Twenty-second meeting 
    
    Meeting purpose: Discuss the teamwork part and perfect er.pdf 
    
    Data and time: 15/11 night
    
    location: CSE drum lab 
    
    Attendees: All members 

    agenda items: 1.Discuss the main idea of teamwork 
                  2. Discuss how to complete er.pdf

    meeting outcome: team members share their ideas on their work in iteration 3, and perfect Joe’s version of er.pdf: add some key relationship between entities

##  Twenty-third meeting 
    
    Meeting purpose: Last checking before submission 
    
    Data and time: 16/11 4pm 
    
    location: UNSW main library 
    
    Attendees: All members 

    agenda items: 1. All the documentation work are posted in right format 
                  2. code is bug-less, runnable and maintainable 
       	          3. All the tests are working and provide good coverage 

    meeting outcome: All the works are perfectly done and we eventually finished our work! 
    (The listing meetings are only the major physical meeting, in fact a active exchange of information have been lasted in the project group chat. As well as, some of the member have performed a series of positive communications personally which eventually result as great improvement in our test code and documentation work.) 


# 2. Demonstration of appropriate use of agile practices to work effectively as a team.

    —Standups 
	Our group has an online group chatting, we usually don’t actually stand up for “Standups”  but we update our progression very diligently. 
	We always make others know whenever we have done any works and we post them in the group chat.  We also tell others what problems we are face to and what we are going to do after we finish the current work. 
	In addition we have a common habit for group coding, we always code together in CSE lab at night. As soon as a problem is raised, we try to solve it alone, if it fails, then we group up and solve it collectively. The another benefit for group coding is we could always check other’s progression when they just sit next to us. So we won’t have any clash in work and coordinating everything well. 
	In iteration 3, we also improve the use of standups when we are group coding, in the past we usually just randomly chat about the progression. But now we try to make it more structural. Every time we start with what we had done and what  problem has been raised, and what is our next step we are heading. So it makes it much more efficient than before.  

	
    —Sprints/iterations   
	Since our project is designed to be done in 3 iterations, it’s compulsory to follow the instructions. However, this experience is actually affecting for all of us. It’s our first time to work on an iteration-based projects and it places us in the real circumstance that how a project is started and worked by multiple people. 
	It also helps us to manage our work and time reasonably, so we can divides our workload into multiple separate stages and parts. When working on a certain part, we are just focusing on the goal we set up and we don't get influenced or overthink it. The iterations-oriented mode is refreshing to us and it really assist our completion of the entire project. 
	We understand “iteration-based project” more in iteration 3, since we have done so much work in the past two iterations. So in iteration 3 we can just focusing on improving the quality of our code. If we didn’t work under iterations, we are probably going to do everything before the deadline but in fact we are in advance and we can produce a much better quality of our code.  

    —Task-boards
	Regarding the suggestion and feedback from iteration2, we decide to apply task-boards in both gitlab and our online group chat. In gitlab, we update the working status every time we finish any tasks. Also, we upload file in our group chat to demonstrate the guide line for each members. It includes the todo list for every members and also the status of them. 
	So that even, we are not together we could still check each other’s progression and understand to do next.
	We didn’t use the task board function in gitlab for last iteration but the tutor points out that when we are working in the real working condition, it is better to keep the notes in gitlab so if new member join in the team, they can view the notes straight. As we are using it, it did offers a second insurance to our documentations.  

    —Pair programming:
	We have been pair programming since iteration one, there are so many good points about pair programming. For us, sometime one person is hard to “think outside of box” when problem raises, so it may take a long time for us to debug our own mistake but with thoughts from others, it make optimise our efficiency. In addition, when two people code together, they can get benefits from other’s ideas. 
	In both way, pair programming can achieve “1+1>2”, for most of code we’ve written, we have applied pair programming.It increase our efficiency by avoiding bugs and refining the code. 
	After we have a deep understanding of each other’s personality, we make 2 regular pair programming group(Yifei and Kyle, Joe and Haowei) base on their ability and time-management. Although we change partners occasionally but regular combination really improves our efficiency. Especially for Yifei and Kyle, Yifei makes Kyle more efficient during work and Kyle also influence Yifei in up-and-down thinking. 

    —Test-Driven-Development
	It’s also necessary for us to write the tests before the functions. Although we find the test is not really runnable after we complete the functions, there are changes made in functions names, structures and some other details. 
	Whereas, during the process of coding the test, we have developed a deep thinking about the test. Even we didn’t write the function, we are aware what kinds of mistakes we should avoid. It stops us from making significant mistakes and makes the project more smooth. 
	Additionally, we can test the function directly by the test when we complete it and check which specific test it fails or pass. It saves lots of time for us to debug and modify the functions rather than writing tests after completion. 
	In this literation, we aggregate all the test into an automated pytest file. It saves our time to avoid running all the unit test one by one. And it make our testing much more easier since it allows us to directly test the back ends without frontend. Also additional tests are included, these thinking allows us to avoid mistakes in code-writing. 

# 3. Consistent work towards the goal of a working backend.

    There are a lots of evidence proving our consistence of work in backend. 	
    —More than 400 times commit in gitlab (Though we don't use gitlab frequently)
    —More than 1500 course-relevant messages in the project groups chat’s message log 
    —Attendance of most group member to the CSE lab in the late night 
    —The recording of task board

    The most important evidence is that, we perfectly complete the project that meets every signal criteria in the spec. 



# 4. Task board is always up to date and reflects ongoing work
	We have taken advantage of the task board in the gitlab for this iterations but as I mentioned in the previous section, we also make recording in our group chat file repository, and it basically follow the general pattern:
		—> completing the additional requirement 
		—> completing the test for the new functions  
		—> integrate all the unit test in an automated test
		—> edit test and ensure their coverage 
		—> editing code and record them 
		—> classify all the changes and conclude how it improves our code
		—> complete all the documentation work 
	We are aware of the importance to keep task board up to date and we apply it in both our group chat APP and gitlab so that we can check it every time we update our progression. 


# 5. demonstration that responsibilities were allocated across team member
	Haowei is taking the leadership throughout the project, since he has got a stronger programming background and he is responsible for designing the data structure, function structure and format. 
	Other 3 members are evenly working on different functions regarding Haowei’s instructions and coordinate with his work. Yifei is more focusing on testing and message functions, Jinning is responsible for channel functions and Haokai is working on user functions. 

# 6. Clear reflection on areas for improvement
 	Generally, we have a great improvement in comparing with last iteration but we can do a better job if we start making strategy earlier. 
	Some time we fail to meet the short term target, we could improve our efficiency if we can execute our plan better.  
	Overall, we’ve done a good job this time, but if we can manage our time more efficient, we would have time time to adjust with front-end and refine our functions. We have been stuck in some silly bugs which is caused by spelling error if we could avoid these mistakes then we will be definitely more well-organised 

# 7. impression that team has worked together collaboratively
	The use of gitlab allows us to check other’s code at any time and also helps us to interact with other’s thought. We were taking advantage of each other’s idea (Haowei’s design for data structure). During our coding process, all the good thoughts are concentrated, eventually the test code is a product of corporation. 
    Additionally, as we mentioned before the maximising individual’s advantaging, exchanging information all the time, regular group meeting, those factors are proving the collaborative teamwork. 
# 8. impression that team has processed in place to work through disagreements or tension
	Obviously, disagreements have exerted and bad atmosphere have been sparked by divergences. However, we always listen to each other and express our own idea logically. The major disagreement happen when Yifei suggests a change in the message dictionary list that element “if_remove” should be added in. But Haowei is not agreeing with that initially and thinks there is a better way to solve the problem.
	However, the conflict is soon solved after Haowei takes Yifei’s suggestion. 

# 9.Impression that team had a thought out methodology for completing the iteration
	The greatest impression is from the process we write our remove function. Since we didn’t consider if_message_remove as a property to a message, so there is no way we can represent this in the functions. So that, we choose the optimal solution to add a new key in the message list dictionary and edit all the relevant functions and tests.
	The process, we find the problem and we state our idea separately and then we choose the optimal solution and apply the changes. The entire methodology is very useful for any arises of problems. 
	Moreover the thought is a smartest way to achieve our goal but brings the least side effects. That saves our time and minimizes future bugs bring up by the edition of entire program. 


