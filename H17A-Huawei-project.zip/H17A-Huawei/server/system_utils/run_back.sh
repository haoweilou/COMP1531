#!/bin/sh
python3 server.py $1
