#COMP1531 porject iteration 2
#write by HaoweiLou
#group H17A-Huawei
#starting a 14 Oct 2019
import sys
from flask_cors import CORS
from json import dumps
from flask import Flask, request, jsonify, send_from_directory
from flask_mail import Mail, Message

from functions import *

APP = Flask(__name__)
APP.config['TRAP_HTTP_EXCEPTIONS'] = True
def defaultHandler(err):
    response = err.get_response()
    response.data = dumps({
        "code": err.code,
        "name": "System Error",
        "message": err.description,
    })
    response.content_type = 'application/json'
    return response

APP.register_error_handler(Exception, defaultHandler)
CORS(APP)
APP.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=465,
    MAIL_USE_SSL=True,
    MAIL_USERNAME = 'HuaweiH17A@gmail.com',
    MAIL_PASSWORD = "L123456."
)
@APP.route('/auth/register', methods=['POST'])
def register():
    result = auth_register(request.form.get('email'),
                        request.form.get('password'),
                        request.form.get('name_first'),
                        request.form.get('name_last'))
    return dumps(result)

@APP.route('/auth/login', methods=['POST'])
def login():
    result = auth_login(request.form['email'],request.form['password'])
    return dumps(result)

@APP.route('/auth/logout', methods=['POST'])
def logout():
    return dumps(auth_logout(request.form['token']))

@APP.route('/auth/passwordreset/request', methods=['POST'])
def get_email():
    email = request.form['email']
    reset_code = auth_resetpassword_request(email)
    if reset_code:
        mail = Mail(APP)
        try:
            msg = Message("Your reset code from Slack",
                            sender = 'HuaweiH17A@gmail.com',
                            recipients = [email])
            msg.body = (f"Your reset code is {reset_code}")
            mail.send(msg)
            return dumps({})
        except ValueError as e:
            return (str(e))

@APP.route('/auth/passwordreset/reset', methods=['POST'])
def reset_email():
    auth_resetpassword_reset(int(request.form['reset_code']), request.form['new_password'])
    return dumps({})
    
@APP.route('/user/profile', methods=['GET'])
def get_user_profile():
    output = user_profile(request.args.get('token'),int(request.args.get('u_id')))
    output['profile_img_url'] = str(request.base_url) + output['profile_img_url']
    return dumps(output)

@APP.route('/user/profile/setname', methods=['PUT'])
def profile_setname():
    return dumps(setname(request.form['token'],request.form['name_first'],request.form['name_last']))

@APP.route('/user/profile/setemail', methods=['PUT'])
def profile_setemail():
    return dumps(setemail(request.form['token'],request.form['email']))

@APP.route('/user/profile/sethandle', methods=['PUT'])
def profile_sethandle():
    return dumps(sethandle(request.form['token'],request.form['handle_str']))

@APP.route('/channels/list', methods=['GET'])
def c_list():
    return dumps(channels_list(request.args.get('token')))

@APP.route('/channels/listall', methods=['GET'])
def list_all():
    return dumps(channels_listall(request.args.get('token')))

@APP.route('/channels/create', methods=['POST'])
def create():
    return dumps(channel_create(request.form['token'], request.form['name'], request.form['is_public']))

@APP.route('/channel/addowner', methods=['POST'])
def addowner():
    return dumps(channel_addowner(request.form['token'],int(request.form['channel_id']),int(request.form['u_id'])))

@APP.route('/channel/removeowner', methods=['POST'])
def removeowner():
    return dumps(channel_removeowner(request.form['token'],int(request.form['channel_id']),int(request.form['u_id'])))

@APP.route('/channel/messages', methods=['GET'])
def read_messages():
    return dumps(channel_messages(request.args.get('token'),int(request.args.get('channel_id')), int(request.args.get('start'))))

@APP.route('/message/edit', methods=['POST','PUT'])
def edit_message():
    return dumps(message_edit(request.form['token'],int(request.form['message_id']),request.form['message']))

@APP.route('/channel/details', methods=['GET'])
def channeldetail():
    output = channel_detail(request.args.get('token'),int(request.args.get('channel_id')))
    for item in output['owner_members']:
        item['profile_img_url'] = str(request.base_url)  + item['profile_img_url']

    for item in output['all_members']:
        item['profile_img_url'] = str(request.base_url)  + item['profile_img_url']
    return dumps(output)

@APP.route('/message/send', methods=['POST'])
def send_message():
    return dumps(message_send(request.form['token'], int(request.form['channel_id']), request.form['message']))

@APP.route('/admin/userpermission/change', methods=['POST'])
def admin_change():
    return dumps(admin_userpermission_change(request.form['token'], int(request.form['u_id']), int(request.form['permission_id'])))

@APP.route('/channel/join', methods=['POST'])
def join_channel():
    return dumps(channel_join(request.form['token'], int(request.form['channel_id'])))

@APP.route('/channel/invite', methods=['POST'])
def invite():
    return dumps(channel_invite(request.form['token'], int(request.form['channel_id']),int(request.form['u_id'])))

@APP.route('/channel/leave', methods=['POST'])
def leave():
    return dumps(channel_leave(request.form['token'], int(request.form['channel_id'])))

@APP.route('/message/remove', methods=['DELETE'])
def remove():
    return dumps(message_remove(request.form['token'], int(request.form['message_id'])))

@APP.route('/message/sendlater', methods=['POST'])
def sendlater():
    return dumps(message_sendlater(request.form['token'], int(request.form['channel_id']),request.form['message'], int(request.form['time_sent'])))

@APP.route('/message/pin', methods=['POST'])
def pin():
    return dumps(message_pin(request.form['token'], int(request.form['message_id'])))

@APP.route('/message/unpin', methods=['POST'])
def unpin():
    return dumps(message_unpin(request.form['token'], int(request.form['message_id'])))

@APP.route('/message/react', methods=['POST'])
def react():
    return dumps(message_react(request.form['token'], int(request.form['message_id']),int(request.form['react_id'])))

@APP.route('/message/unreact', methods=['POST'])
def unreact():
    return dumps(message_unreact(request.form['token'], int(request.form['message_id']),int(request.form['react_id'])))   

@APP.route('/standup/start', methods=['POST']) 
def standup():
    return dumps(standup_start(request.form['token'],int(request.form['channel_id']),int(request.form['length'])))

@APP.route('/standup/send', methods=['POST']) 
def send_standup():
    return dumps(standup_send(request.form['token'],int(request.form['channel_id']), request.form['message']))

@APP.route('/standup/active', methods=['GET']) 
def standup_active():
    return dumps(standup_is_active(request.args.get('token'),int(request.args.get('channel_id'))))

@APP.route('/search', methods=['GET']) 
def search_by_string():
    return dumps(search(request.args.get('token'), request.args.get('query_str')))

@APP.route('/users/all', methods=['GET']) 
def list_all_user():
    return dumps(users_list(request.args.get('token')))

@APP.route('/user/profile/image', methods=['GET'])
def output_image():
    image = request.args.get('file')
    return send_from_directory('./image',image)

@APP.route('/channel/details/image', methods=['GET'])
def output_image_in_channel():
    image = request.args.get('file')
    return send_from_directory('./image',image)

@APP.route('/user/profiles/uploadphoto',methods=['POST'])
def uploadphoto():
    return dumps(user_profile_upload_photo(request.form['token'],request.form['img_url'],
                int(request.form['x_start']),int(request.form['y_start']),
                int(request.form['x_end']),int(request.form['y_end'])))

if __name__ == '__main__':	
    APP.run(port=(sys.argv[1] if len(sys.argv) > 1 else 5000), debug = True)
