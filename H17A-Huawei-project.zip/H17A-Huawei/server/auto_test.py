#COMP1531 porject iteration 2
#write by HaoweiLou
#group H17A-Huawei
#starting a 13 Oct 2019
import pytest
from functions import *

#-------------------->automated python test<-----------------------------

#------------------->default infomation for test-----------------------
user_info = auth_register("unsw@gmail.com", "password", "haowei", "lou")
token = user_info["token"]
u_id = user_info["u_id"]

user_info2 = auth_register("unsw2@gmail.com", "password", "haokai", "zhao")
token2 = user_info2["token"]
u_id2 = user_info2["u_id"]

user_info3 = auth_register("unsw3@gmai.com", "password", "yifei", "luo")
token3 = user_info3["token"]
u_id3 = user_info3["u_id"]

user_info4 = auth_register("unsw4@gmail.com", "password", "jinning", "liu")
token4 = user_info4["token"]
u_id4 = user_info4["u_id"]

channel_info = channel_create(token,"channel1",True) 
channel_id = channel_info["channel_id"]

channel_info2 = channel_create(token2,"channel2", True) 
channel_id = channel_info["channel_id"]

channel_info3 = channel_create(token2,"channel3",False) 
channel_id = channel_info["channel_id"]

time_after5 = datetime.now() + timedelta(seconds=5)
time_before5 = datetime.now() - timedelta(seconds=5)

#-------------------->auth_register_test--------------------------------
@pytest.mark.run(order=1)
def test_non_valid_email():
    with pytest.raises(ValueError):
        auth_register("111111", "password", "haowei", "lou") #when email is an invalid email, raise ValueError
    with pytest.raises(ValueError):     
        auth_register("haoweilougmail.com", "password", "haowei", "lou") #another invalid email
@pytest.mark.run(order=2)
def test_registered_email():
     with pytest.raises(ValueError):
        auth_register("unsw@gmail.com", "password", "haowei", "lou") #when email is an registed, raise ValueError
@pytest.mark.run(order=3)
def test_invalid_password():
    with pytest.raises(ValueError):
        auth_register("haoweilou@gmail.com", "pass", "haowei", "lou") #when password is lower than 5 characters, raise ValueError
    with pytest.raises(ValueError):
        auth_register("haoweilou@gmail.com", "pa12", "haowei", "lou")#another lower than 5 characters password
@pytest.mark.run(order=4)
def test_invalid_first_name():
    with pytest.raises(ValueError):
        auth_register("haoweilou@gmail.com", "pass1", "h"*51, "lou")#when first name is greater than 50 characters(51 in this one), raise ValueError
@pytest.mark.run(order=5)
def test_invalid_last_name():    
    with pytest.raises(ValueError):        
        auth_register("haoweilou@gmail.com", "pass1", "haowei", "l"*51)#when last name is greater than 50 characters(51 in this one), raise ValueError
@pytest.mark.run(order=6)
def test_invalid_both_name():        
    with pytest.raises(ValueError):        
        auth_register("haoweilou@gmail.com", "pass1", "h"*51, "l"*51)
        #when both first name and last name is greater than 50 characters(51 in this one), raise ValueError
@pytest.mark.run(order=7)
def test_repeated_name():
    user_info = auth_register("unswx2@gmail.com" ,"password","haowei","lou")
    #when both email and password are correct, return token and u_id for that user
    tokenx2 = user_info["token"]
    u_idx2 = user_info["u_id"]
    #assert the generated token is a valid token, and the u_id refer to the same
    #user who register the token linked account
    assert user_profile(tokenx2,u_idx2) == {"email":"unswx2@gmail.com", 
                                        "name_first":"haowei", "name_last":"lou", 'handle_str': 'haoweilou0','profile_img_url': '/image?file=default.jpg'}
@pytest.mark.run(order=8)
def test_verififies_password_email():
    u_id = user_info["u_id"]
    #assert the generated token is a valid token, and the u_id refer to the same
    #user who register the token linked account
    assert user_profile(token,u_id) == {"email":"unswx2@gmail.com", 
                                        "name_first":"haowei", "name_last":"lou", 'handle_str': 'haoweilou','profile_img_url': '/image?file=default.jpg'}

#-------------------------->auth_login_test------------------------------
@pytest.mark.run(order=9)
def test_invalid():
    with pytest.raises(ValueError):
        auth_login("123456", "123456") #when email is an invalid email, raise ValueError
@pytest.mark.run(order=10)        
def test_email_not_belong_to_users():
    with pytest.raises(ValueError):        
        auth_login("unsw@gmail.com", "123456") #when email is not belong to a user, raise ValueError
    
@pytest.mark.run(order=11)    
def test_invalid_password():
    auth_register("haowei@gmail.com", "123456", "haowei", "haowei")
    with pytest.raises(ValueError):
        auth_login("haowei@gmail.com","123421356") #when password is incorrect, raise a value error
@pytest.mark.run(order=12)
def test_verififies_password_email():
    #assert the generated token is a valid token, and the u_id refer to the same
    #user who register the token linked account
    assert user_profile(token,u_id) == {"email":"unsw@gmail.com", 
                                        "name_first":"haowei", "name_last":"lou", 'handle_str': 'haoweilou', 'profile_img_url': '/image?file=default.jpg'}
     
#---------------------------->auth_passwordreset_reset_test-----------------
@pytest.mark.run(order=13)
def test_passwordrest_request():
    user_info = auth_register("unswx5@gmail.com", "password", "haowei2", "lou2")
    code = auth_resetpassword_request("unswx5@gmail.com")
    auth_resetpassword_reset(code,"654321")#check reset code is "1234"
    user_info = auth_login("unswx5@gmail.com","654321") #check user can login with his new password
    #check after change password, the person still be that person
    assert user_profile(user_info['token'],user_info['u_id']) == {'email': 'unswx5@gmail.com', 
                                                                  "name_first":"haowei2", "name_last":"lou2", 
                                                                  "handle_str":"haowei2lou2",'profile_img_url': '/image?file=default.jpg'}
@pytest.mark.run(order=14)    
def test_invalid_email():
    assert auth_resetpassword_request("invalidemail") == None 
@pytest.mark.run(order=15)         
def test_not_registered_email():
    assert auth_resetpassword_request("dsa@dsdas.com") == None      
                                        
                                        
#---------------------------->auth_passwordreset_reset_test-----------------
@pytest.mark.run(order=16)
def test_wrong_reset_code():
    user_info = auth_register("unswx1@gmail.com", "password", "haowei", "lou")
    code = auth_resetpassword_request("unswx1@gmail.com")
    with pytest.raises(ValueError):
        #when reset code is wrong, raise ValueError
        auth_resetpassword_reset(code-1,"12345") 
@pytest.mark.run(order=17)
def test_wrong_password_short():
    user_info = auth_register("unswx3@gmail.com", "password", "haowei", "lou")
    #assume the reset code sent is "1234"
    code = auth_resetpassword_request("unswx3@gmail.com")
    with pytest.raises(ValueError):
        #when reset code is correct, but password is invalid (lower than 5) raise ValueError
        auth_resetpassword_reset(code,"1234")
    with pytest.raises(ValueError):       
        #when password is 1 character
        auth_resetpassword_reset(code,"1") 
@pytest.mark.run(order=18)       
def test_right_reset_code_password():
    user_info = auth_register("unswx4@gmail.com", "password", "haowei1", "lou1")
    code = auth_resetpassword_request("unswx4@gmail.com")
    auth_resetpassword_reset(code,"654321")
    user_info = auth_login("unswx4@gmail.com","654321")#check user can login with his new password
    #check after change password, the person still be that person
    assert user_profile(user_info["token"],user_info["u_id"]) == {"email":"unswx4@gmail.com", 
                                                                  "name_first":"haowei1", "name_last":"lou1", 
                                                                  "handle_str":"haowei1lou1", 'profile_img_url': '/image?file=default.jpg'}
                                      
#------------------------->user_profile_test------------------------------                            
@pytest.mark.run(order=19)
def test_invalid_token():    
    # assume an invalid u_id is -1
    with pytest.raises(ValueError): 
        user_profile(token, -1)
@pytest.mark.run(order=20)   
def test_happy_case():    
    # assert the profile return right things if success
    # assume a valid handle_str is "handle_str"
    assert user_profile(token, u_id) == {"email":"unsw@gmail.com","name_first":"haowei", "name_last":"lou", 
                                       "handle_str":"haoweilou", 'profile_img_url': '/image?file=default.jpg'}
                                      
#------------------------>user_profile_setname---------------------------
#test if the first_name string is long than 50 
#it should result in a value error
#otherwise it will update the name and it's further comfirmed by user_profile function 
@pytest.mark.run(order=21)
def test_firstname():
    with pytest.raises(ValueError) as error:
         #when it's more than 50 characters in the first name 
         setname(token,"1"*51,"hello")
    
#test if the last_name string is long than 50 
#it should result in a value error
#otherwise it will update the name and it's further comfirmed by user_profile function    
@pytest.mark.run(order=22)
def test_lastname():
    with pytest.raises(ValueError) as error:
         #when it's more than 50 characters in the last name 
         setname(token,"hello","1"*51)

#test if the both last and first name string is long than 50 
#it should result in a value error
#otherwise it will update the name and it's further comfirmed by user_profile function
@pytest.mark.run(order=23)
def test_both():
    with pytest.raises(ValueError) as error:
         #when it's more than 50 characters for both name 
         setname(token,"1"*51,"1"*51)
@pytest.mark.run(order=24)
def test_happy_case():
    setname(token,"123456789","hello") 
    assert user_profile(token,u_id) == {"email":"unsw@gmail.com", 
                                        "name_first":"123456789", "name_last":"hello", 
                                        "handle_str":"haoweilou", 'profile_img_url': '/image?file=default.jpg'}
                                       
#-------------------->user_profile_sethandle----------------------------
@pytest.mark.run(order=25)
def test_if_work():
    #run the set_sethandle fucntion
    sethandle(token4,"stuff_a_word_here")
    assert user_profile(token4,u_id4) == {"email":"unsw4@gmail.com", 
                                          "name_first":"jinning", "name_last":"liu", 
                                          "handle_str":"stuff_a_word_here", 'profile_img_url': '/image?file=default.jpg'}
@pytest.mark.run(order=26)
def test_same_name():
    #run the set_sethandle fucntion
    with pytest.raises(ValueError) as error:
            sethandle(token3,"yifeiluo")
        
#here we just are just testing the situation 
#when the handle string input is longer than 20 characters 
#and it should return a value erroor 
#if the length is legal then handle name should be changed
@pytest.mark.run(order=27)
def test_handle_too_long():
    with pytest.raises(ValueError) as error:
         #when the handle string is too long(more than 20 characters)
         sethandle(token,"123456789012345678901")
@pytest.mark.run(order=28)
def test_handle_too_short():
    with pytest.raises(ValueError) as error:
         sethandle(token,"aa")
         
#----------------->user_profile_setemail----------------------------         
@pytest.mark.run(order=29)
def test_email_valid():
    #when the email is not valid
    with pytest.raises(ValueError) as error:
        setemail(token,"huawei")

@pytest.mark.run(order=30)
def test_email_used():
    with pytest.raises(ValueError) as error:   
         setemail(token,"unsw2@gmail.com")

@pytest.mark.run(order=31)
def test_happy_case():    
    user_info5 = auth_register("unsw5@gmail.com", "password", "comp", "1531")
    token5 = user_info5["token"]
    u_id5 = user_info5["u_id"]
    setemail(token5,"unsw55@gmail.com")    
    assert user_profile(token5, u_id5) == {'email':"unsw55@gmail.com",'name_first':"comp",
            'name_last':"1531",'handle_str':"comp1531",'profile_img_url': '/image?file=default.jpg'}

#---------------->channel_create-----------------------------------
@pytest.mark.run(order=32)
def test_long_name(): 
    with pytest.raises(ValueError):
         channel_create(token,"1"*100,True) 
@pytest.mark.run(order=33)   
def test_happy_case():    
    assert channels_list(token) == {'channels': [{'channel_id': 0, 'name': 'channel1'}]} 

#----------------> channel_invite-----------------------------------
# when channel id does not exist, raise ValueError
@pytest.mark.run(order=34) 
def test_no_exsit_channel_id():
    # assume -1 is a not exsit channel id
    with pytest.raises(ValueError):
         channel_invite(user_info["token"], -1, user_info2['u_id']) 
@pytest.mark.run(order=35) 
def test_non_valid_user_id():
    with pytest.raises(ValueError):
         # when user id does not refer to a valid user, raise ValueError
         # assume -2 is a user that does not exist
         channel_invite(user_info["token"], channel_info['channel_id'], -2)
@pytest.mark.run(order=36) 
def test_no_belong_channel():
    # user01 is not belong to "channel1", he can't invit anyone to join this channel
    with pytest.raises(AccessError):
         channel_invite(user_info2['token'], channel_info['channel_id'], user_info3['u_id']) 
@pytest.mark.run(order=37) 
def test_valid_input():
    #check initial channel as fowlling
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}]}

    channel_invite(user_info["token"], channel_info['channel_id'], user_info['u_id'])
    print(channel_detail(user_info["token"], channel_info['channel_id']))
    #check after inviting, unsw has been successfully enrolled in this channel
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}]}

#----------------> channel_join-----------------------------------
# when channel id is not a valid id, raise ValueError
@pytest.mark.run(order=38) 
def test_no_exsit_channel_id():
    # assume 5 is a not exsit channel id
    with pytest.raises(ValueError):
         channel_join(user_info2["token"], 5) 
@pytest.mark.run(order=39)          
def test_private():
    # when the channel is private, the only way to join this channel is invited by owner
    with pytest.raises(AccessError):
         channel_join(user_info3["token"], channel_info3['channel_id']) 
@pytest.mark.run(order=40)     
def test_valid_input():
    #check initial channel as fowlling
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}]}

    channel_join(user_info["token"], channel_info['channel_id'])
     
    #check after inviting, unsw has been successfully enrolled in this channel
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}]}

#---------------->channel_leave-----------------------------------
# when channel id is not a valid id, raise ValueError
@pytest.mark.run(order=41)   
def test_no_exsit_channel_id():
    # assume 5 is a not exsit channel id
    with pytest.raises(ValueError):
          channel_leave(user_info2["token"], 5) 
@pytest.mark.run(order=42)   
def test_valid_input():
    #check initial channel as fowlling
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}]}

    channel_leave(user_info["token"], channel_info['channel_id'])

    #check after inviting, unsw has been successfully enrolled in this channel
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [], 'all_members': []}

#---------------->channel_removeowner-----------------------------------
# when channel id is not a valid id, raise ValueError
@pytest.mark.run(order=43) 
def test_invalid_channel_id():
    # assume 5 is a not exsit channel id
    with pytest.raises(ValueError):
         channel_removeowner(user_info["token"], 5, user_info2['u_id']) 
@pytest.mark.run(order=44) 
def test_ownercase():
    # when the user has already been an owner
    with pytest.raises(ValueError):
         channel_removeowner(user_info["token"], channel_info["channel_id"], user_info3["u_id"])  
@pytest.mark.run(order=45) 
def test_notowner():
    # when the authorised user is not an owner
    print(DATA['channellist'][0]['member'])   
    channel_invite(user_info["token"], channel_info["channel_id"], user_info2["u_id"])
    with pytest.raises(ValueError):
         channel_removeowner(user_info["token"], channel_info["channel_id"], user_info2["u_id"])  
@pytest.mark.run(order=46) 
def test_valid_input():
    channel_addowner(user_info["token"], channel_info["channel_id"], user_info3["u_id"]) 
    #check initial channel as fowlling
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 2, 'name_first': 'yifei', 'name_last': 'luo', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 1, 'name_first': 'haokai', 'name_last': 'zhao', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 2, 'name_first': 'yifei', 'name_last': 'luo', 'profile_img_url': '/image?file=default.jpg'}]}
    
    channel_removeowner(user_info["token"], channel_info["channel_id"], user_info3["u_id"]) 
    print(channel_detail(user_info["token"], channel_info['channel_id']))
    #check after inviting, unsw has been successfully enrolled in this channel
    assert channel_detail(user_info["token"], channel_info['channel_id']) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 1, 'name_first': 'haokai', 'name_last': 'zhao', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 2, 'name_first': 'yifei', 'name_last': 'luo', 'profile_img_url': '/image?file=default.jpg'}]}
    
#---------------->channel_detail-----------------------------------
@pytest.mark.run(order=47) 
def test_channel_id():
    # when the channel_id corresponding to a non-existing channel
    with pytest.raises(ValueError):
        channel_detail(user_info["token"], -1)
    with pytest.raises(ValueError):
        channel_detail(user_info["token"], 3)
@pytest.mark.run(order=48)     
def test_user_in_channel():
    # when user is not in channel and not admin and channel is not public
    with pytest.raises(AccessError):
        channel_detail(token3, 2)
@pytest.mark.run(order=49)      
def test_success_case():
    # when success, check output
    assert channel_detail(token, 0) == {'name': 'channel1', 'owner_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}], 'all_members': [{'u_id': 0, 'name_first': 'haowei', 'name_last': 'lou', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 1, 'name_first': 'haokai', 'name_last': 'zhao', 'profile_img_url': '/image?file=default.jpg'}, {'u_id': 2, 'name_first': 'yifei', 'name_last': 'luo', 'profile_img_url': '/image?file=default.jpg'}]}

#---------------->channel_list-----------------------------------
@pytest.mark.run(order=50)  
def test_channel_list():
    # test on different user's channel list
    assert channels_list(token) == {'channels': [{'channel_id': 0, 'name': 'channel1'}]}
    assert channels_list(user_info2["token"]) == {'channels': [{'channel_id': 0, 'name': 'channel1'}, {'channel_id': 1, 'name': 'channel2'}, {'channel_id': 2, 'name': 'channel3'}]}
    assert channels_list(user_info3["token"]) == {'channels': [{'channel_id': 0, 'name': 'channel1'}]}

#---------------->channel_listall-----------------------------------
@pytest.mark.run(order=51)  
def test_channel_list_all():
    # test on different user's all channel list
    assert channels_listall(user_info["token"]) == {'channels': [{'channel_id': 0, 'name': 'channel1'}, {'channel_id': 1, 'name': 'channel2'}, {'channel_id': 2, 'name': 'channel3'}]}
    assert channels_listall(user_info3["token"]) == {'channels': [{'channel_id': 0, 'name': 'channel1'}, {'channel_id': 1, 'name': 'channel2'}, {'channel_id': 2, 'name': 'channel3'}]}
    assert channels_listall(user_info2["token"]) == {'channels': [{'channel_id': 0, 'name': 'channel1'}, {'channel_id': 1, 'name': 'channel2'}, {'channel_id': 2, 'name': 'channel3'}]}
    
#---------------->message_edit-----------------------------------
@pytest.mark.run(order=51)  
def test_message_selfedit():
    message_send(user_info["token"], channel_info["channel_id"], "message before")
    message_info = DATA['message_list'][0]
    # edited this message by user01, which should be success
    message_edit(user_info["token"], message_info["message_id"], "message self edited")
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message self edited'
    pass
@pytest.mark.run(order=52)  
def test_message_otheredit():
    # edited this message by user02, who is not the poster of this message
    # which should raise a value error
    message_info = DATA['message_list'][0]
    with pytest.raises(AccessError):
        message_edit(user_info2["token"], message_info["message_id"], "message other edited")
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message self edited'
@pytest.mark.run(order=53)  
def test_message_adminedit():
    message_send(user_info["token"], channel_info["channel_id"], "message before")
    message_info = DATA['message_list'][0]
    # edited this message by admin, which should be success
    message_edit(user_info["token"], message_info["message_id"], "message admin edited")
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message admin edited'
@pytest.mark.run(order=54)  
def test_empty_string():
    message_send(user_info["token"], channel_info["channel_id"], "message before")
    message_info = DATA['message_list'][0]
    # if the new message is empty, the message should be removed
    print(DATA['message_list'][0])
    message_edit(user_info["token"], 0, '')
    assert DATA['message_list'][0]['is_removed'] == True
    
#---------------->message_pin-----------------------------------
@pytest.mark.run(order=55)  
def test_happy_case():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned
    assert message_pin(token, message_id) == {}
@pytest.mark.run(order=56)      
def test_invalid_massage():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned
    with pytest.raises(ValueError):
        message_pin(token, 0)
@pytest.mark.run(order=57)           
def test_invalid_user():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned, send the message id 0 is not send by user0
    with pytest.raises(ValueError):
        message_pin(user_info['token'], 0)   
@pytest.mark.run(order=58)                
def test_pinned():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned
    with pytest.raises(ValueError):
        message_pin(token, 0)
@pytest.mark.run(order=59)             
def test_invalid_user():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned, send the message id 0 is not send by user0
    with pytest.raises(ValueError):
        message_pin(user_info['token'], 0)   
@pytest.mark.run(order=60)                
def test_pinned():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    message_pin(token, message_id)  
    with pytest.raises(ValueError):
        message_pin(token, message_id)        
@pytest.mark.run(order=61)      
def test_pin_from_other_channel():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned
    #since the slack admin can pin any message in any channel
    assert message_pin(token, message_id) == {}

#---------------->message_react-----------------------------------
@pytest.mark.run(order=62)
def test_invalid_react_id():    
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # add a "react" to this message with invalid react_id,
    # which should raise a value error
    # assume an invalid react_id is 654321
    with pytest.raises(ValueError):
        message_react(token, message_id, 654321)        
    # add a "react" to that particular message
    # assume a valid react_id is 1
    react_id = 1
    assert message_react(token, message_id, react_id) == {}

@pytest.mark.run(order=63)
def test_invalid_message_id():    
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # add a "react" to an invalid message_id, which should raise a value error
    # assume an invalid message_id is 0
    with pytest.raises(ValueError):
        message_react(token, 0, 0) 
@pytest.mark.run(order=64)
def test_repeated_react():    
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    assert message_react(token, message_id, 1) == {}
    # add a "react" to a message that already contains a react,
    # which should return a value error
    with pytest.raises(ValueError):
        message_react(token, message_id, 2)

#---------------->message_remove-----------------------------------
@pytest.mark.run(order=65)
def test_message_otheremove():
    # remove this message by user02, who is not the poster of this message
    # which should raise a value error   
    print(DATA["message_list"])
    with pytest.raises(AccessError):
        message_remove(user_info2["token"], 0)
    message = DATA['message_list'][0]
    assert message['is_removed'] == False
@pytest.mark.run(order=66)
def test_message_selfremove():
    # remove this message by user01, which should be success
    message_remove(user_info["token"], 1)    
    message = DATA['message_list'][1]
    assert message['is_removed'] == True
@pytest.mark.run(order=67)    
def test_message_adminremove():
    # remove this message by admin, which should be success
    message_remove(user_info["token"], 2)    
    message = DATA['message_list'][2]
    assert message['is_removed'] == True    

#---------------->message_edit-----------------------------------
@pytest.mark.run(order=68)
def test_message_selfedit():
    # edited this message by user01, which should be success
    message_info = DATA['message_list'][0]
    message_edit(user_info["token"], message_info["message_id"], "message self edited")
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message self edited'

@pytest.mark.run(order=69)
def test_message_otheredit():
    # edited this message by user02, who is not the poster of this message
    # which should raise a value error
    message_info = DATA['message_list'][0]
    with pytest.raises(AccessError):
            message_edit(user_info2["token"], message_info["message_id"], "message before")    
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message self edited'
@pytest.mark.run(order=70)
def test_message_adminedit():
    message_info = DATA['message_list'][0]
    # edited this message by admin, which should be success
    message_edit(user_info["token"], message_info["message_id"], "message admin edited")
    assert DATA['message_list'][0]['channel_id'] == 0
    assert DATA['message_list'][0]['message'] == 'message admin edited'

@pytest.mark.run(order=71)
def test_empty_string():
    # if the new message is empty, the message should be removed
    message_info = DATA['message_list'][0]
    message_edit(user_info["token"], 0, '')
    assert DATA['message_list'][0]['is_removed'] == True
    
#---------------->message_pin-----------------------------------
@pytest.mark.run(order=72)
def test_happy_case():
    message_send(token, 0, 'here we are')
    # mark the message as pinned
    assert message_pin(token, len(DATA['message_list'])-1) == {}
    assert DATA['message_list'][len(DATA['message_list'])-1]['is_pinned'] == True
@pytest.mark.run(order=73)
def test_invalid_massage():
    # mark the message as pinned
    with pytest.raises(ValueError):
        message_pin(token, 0)
@pytest.mark.run(order=74)           
def test_invalid_user():
    # mark the message as pinned, send the message id 1 is not send by user1
    with pytest.raises(ValueError):
        message_pin(token, 1)   

@pytest.mark.run(order=75)              
def test_pinned(): 
    with pytest.raises(ValueError):
        message_pin(token, len(DATA['message_list'])-1)      

@pytest.mark.run(order=76)       
def test_pin_from_other_channel():
    # mark the message as pinned
    #since the slack admin can pin any message in any channel
    message_unpin(token, len(DATA['message_list'])-1)
    assert message_pin(token, len(DATA['message_list'])-1) == {}
    assert DATA['message_list'][len(DATA['message_list'])-1]['is_pinned'] == True
    
#---------------->message_unpin-----------------------------------
@pytest.mark.run(order=77)  
def test_happy_case():
    message_send(token, 0, "yo!!")
    # mark the message as pinned
    message_pin(user_info['token'], len(DATA['message_list'])-1)
    assert message_unpin(user_info['token'], len(DATA['message_list'])-1) == {}

@pytest.mark.run(order=78)    
def test_invalid_massage():
    # mark the message as pinned
    with pytest.raises(ValueError):
        message_unpin(user_info['token'], 0)
@pytest.mark.run(order=79)          
def test_invalid_user():
    # mark the message as pinned
    with pytest.raises(ValueError):
        message_unpin(token, len(DATA['message_list'])-1)   
@pytest.mark.run(order=80)             
def test_pinned():
    # send a message to the chennel and get the message_id
    message = message_send(user_info['token'], channel_id, "message")    
    message_id = message['message_id']
      
    with pytest.raises(ValueError):
        message_unpin(user_info['token'], message_id)        
@pytest.mark.run(order=81)          
def test_pin_from_other_channel():
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # mark the message as pinned
    assert message_pin(user_info['token'], message_id) == {} 
     
#---------------->message_send-----------------------------------
@pytest.mark.run(order=82)  
def test_message():
    long_message = ''
    for char in range(1001):
        long_message += 'a'
    with pytest.raises(ValueError):
        message_send(user_info['token'], 0, long_message)
@pytest.mark.run(order=83)
def test_success():
    # assert the returned value
    assert message_send(user_info['token'], 0, 'message') == {'message_id': 6}
    # assert the message is sent to the channel
    print(channel_messages(user_info['token'], 0, 0))
    assert channel_messages(user_info['token'], 0, 0) == {'messages': [{'message_id': 6, 'u_id': 0, 'message': 'message', 'time_created': DATA['message_list'][6]['time_created'].replace(tzinfo=timezone.utc).timestamp(), 'reacts': [{'react_id': 1, 'u_ids': [], 'is_this_user_reacted': False}], 'is_pinned': False}, {'message_id': 5, 'u_id': 0, 'message': 'message', 'time_created': DATA['message_list'][5]['time_created'].replace(tzinfo=timezone.utc).timestamp(), 'reacts': [{'react_id': 1, 'u_ids': [], 'is_this_user_reacted': False}], 'is_pinned': True}, {'message_id': 4, 'u_id': 0, 'message': 'message', 'time_created': DATA['message_list'][4]['time_created'].replace(tzinfo=timezone.utc).timestamp(), 'reacts': [{'react_id': 1, 'u_ids': [], 'is_this_user_reacted': False}], 'is_pinned': False}, {'message_id': 3, 'u_id': 0, 'message': 'yo!!', 'time_created': DATA['message_list'][3]['time_created'].replace(tzinfo=timezone.utc).timestamp(), 'reacts': [{'react_id': 1, 'u_ids': [], 'is_this_user_reacted': False}], 'is_pinned': False}], 'start': 0, 'end': -1}

#---------------->message_unreact-----------------------------------
@pytest.mark.run(order=84)  
def test_invalidreact_id():
    # create a channel 
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # add a "react" to this message with invalid react_id,
    # which should raise a value error
    # assume an invalid react_id is 654321
    with pytest.raises(ValueError):
         message_unreact(token, message_id, 654321)        
    # add a "unreact" to that particular message
    # assume a valid react_id is 1
    react_id = 1
    message_react(token, message_id, react_id)
    assert message_unreact(token, message_id, react_id) == {}

@pytest.mark.run(order=83)  
def test_invalid_message_id1():    
    # to get a token, register a user and login  
    # create a channel 
    channel = channel_create(token, "Joe's channel", True)
    channel_id = channel['channel_id']
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # add a "unreact" to an invalid message_id, which should raise a value error
    # assume an invalid message_id is 0
    with pytest.raises(ValueError):
        message_unreact(token, -1, 1) 
@pytest.mark.run(order=84)  
def test_repeated_react1():    
    # to get a token, register a user and login  
    # create a channel 
    channel = channel_create(token, "Joe's channel", True)
    channel_id = channel['channel_id']
    # send a message to the chennel and get the message_id
    message = message_send(token, channel_id, "message")    
    message_id = message['message_id']
    
    # add a "unreact" to a message that has no react,
    # which should return a value error
    with pytest.raises(ValueError):
        message_unreact(token, message_id, 2)
             
#---------------->message_sendlater----------------------------------
import time
def test_channel():
    message_sendlater(user_info["token"], channel_info["channel_id"], "hello", time_after5)
    
    while True:
        time.sleep(5)     # delay for 5 seconds 
        break
    
    assert DATA['message_list'][0]['channel_id'] == channel_info['channel_id']
    assert DATA['message_list'][-1]['message'] == 'hello'
     # assume start from the most recent message 
    
    with pytest.raises(ValueError):
        message_sendlater(user_info["token"], -1, "hello", time_after5) # when the channel does not exist
    
def test_length():
    with pytest.raises(ValueError):
        message_sendlater(user_info["token"], channel_info["channel_id"], "hello"*300, time_after5) # the case the message is longer than 1000 characters

def test_time():
    with pytest.raises(ValueError):
        message_sendlater(user_info["token"], channel_info["channel_id"], "hello", datetime.utcnow()-timedelta(seconds = 10)) # the case the time is in the past
#----------------------->standup_start------------------
def test_invalid_length():
    with pytest.raises(ValueError):        
        standup_start(token, channel_id, -1)
      
#---------------------->user_list---------
def test_user_list():    
    assert users_list(token) != {}

#---------------->standup_send-----------------------------------
def test_message2():
    long_message = ''
    for char in range(1001):
        long_message += 'a'
    with pytest.raises(ValueError):
        standup_send(user_info["token"], 0, long_message)


def test_channel_id1():
    with pytest.raises(AccessError):
        standup_send(user_info["token"], 1,'message')
    pass
    
def test_active():
    DATA['channellist'][0]['stand_up']['timeout'] = datetime.utcnow() - timedelta(minutes=15)
    with pytest.raises(AccessError):
        standup_send(token2, 0, 'message')
    DATA['channellist'][0]['stand_up']['timeout'] = datetime.utcnow() + timedelta(minutes=15)

def test_success3():
    standup_start(user_info["token"],1,100)
    standup_send(user_info["token"],1,'m2')
    assert DATA['message_list'][-1]['message'] == 'haoweilou: m2\n'
    standup_send(user_info["token"],1,'m1')
    assert DATA['message_list'][-1]['message'] == 'haoweilou: m2\nhaoweilou: m1\n'
    
#--------------------------->search----------------------
#user huawei creats channel1 
#and he has sent 3 messages in the channel
#here we test the function with valid token 
#when we input key words that is not related to any message in the collection of messages 
#it should returns a empty dictionary 
#if it relates to any of message, it should show them in a dictionary        
def test_no_message_sent(): 
    #assume there are no
    assert search(token, "huawei") == {'messages': []}
def test_find_message(): 
    message_send(token,channel_id,"comp1531")
    time1 = DATA['message_list'][0]['time_created'].replace(tzinfo=timezone.utc).timestamp()   
    #assume there are 3 messages "comp1531 is bad" and "comp1531 is good" related to 1531 in the collection of messages 
    output = search(token, "comp")
    assert output != ({})

def test_no_find():  
    #assume there are 3 messages "comp1531 is bad" and "comp1531 is good" related to 1531 in the collection of messages 
    assert search(token, "not_exist") == {'messages': []}
               
#---------------------->permission_change------------------  
def test_valid_u_id():
    assert DATA['userlist'][0]['privilege'] == 1
    #assume uid 000000 is not a valid id
    with pytest.raises(ValueError) as error:
    #when the uid does not refer to a valid user   
        admin_userpermission_change(token , -1 , 2)

def test_user_already_admin():
    with pytest.raises(AccessError) as error:
        admin_userpermission_change(token2, u_id3, 2)
              
#the only valid permission value we have assumed is 1 and 2
#so if we inputing 3 as a permission value
#it will raisd a value error
#otherwise it will return a None       
def test_valid_permission_id():
    with pytest.raises(ValueError) as error:   
        #when the permission_id of 4 is not valid
        admin_userpermission_change(token, 1 , 4)

#user apple is just a memeber with permission value of 2
#so when he try to change other's permission
#it will result as a access error
#when user huawei who is a admin with permission value of 1
#use admin_changepermission on apple
#it will work and return a None         
def test_authorise():
    #make owner with id 1 become member(not admin)
    admin_userpermission_change(token, 1 , 3)
    with pytest.raises(AccessError) as error:
        admin_userpermission_change(token2, 1 , 1)       

