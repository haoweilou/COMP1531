# 1. Highlighting the time and outcome of team meetings for iteration 2

##  meeting agenda 

##  Seventh meeting 

    Meeting purpose: team building 

    Data and time: 16/10 2pm

    location: main library 

    Attendees: all members 

    agenda items: 
            1. discuss the spec for iteration 2  
            2. construct the general plan for iteration 2 

    meeting outcome: We decide to design our data structure structures before we officially start other works. Since we all agree that a good data structures is the key for the final success. 

    Below is the initial data structure we?ve designed 

    data = { 
        'userlist' : [user], 
        'channellist' : [channel], 
        'reset_code_list': [integer], 
        'message_list':[message] 
    } 

    user = { 
        'email' : email, 
        'password' : hashedPassword, 
        'name_first' : name_first, 
        'name_last' : name_last, 
        'u_id' : len(userlist) + 1, 
        'handle' : handle, 
        'active' : False, 
        'privilege' : 0, 
        'reset_code' : None 
    } 

    channel = { 
        'name' : name, 
        'channel_id' : channel_id, 
        'is_public' : is_public, 
        'owner' : [u_id], 
        'member' : [u_id], 
        'messages': [] 
    } 

    message = { 
        'message_id' : len(data['message_list']) + 1, 
        'u_id' : u_id, 
        'channel_id' : channel_id, 
        'message' : message, 
        'time_created' : datetime.now(), 
        'is_unread' : True, 
        'reacts' : [], 
        'is_pinned': False 
    }

    
##  Eighth meeting 
    
    Meeting purpose: Distribute the workload and responsibilities 
    
    Data and time: 18/10 night 
    
    location: UTS library 
    
    Attendees: All members 
    
    agenda items: 1. decide the task for each member 

    meeting outcome: Base on our plan made in iteration 1, We decide Haowei will be taking the leadership in the building the authentication section, so that we can construct a solid foundation for the following work. For others, we also arrange the responsibility for each member. 
 
    Haowei - Authentication, message, channels 
    Jinning - message, user 
    Haokai - channels, user 
    Yifei - Authentication, channels 

##  Ninth meeting 
    
    Meeting purpose: Communication after the completion of first draft
    
    Data and time: 19/10 night 
    
    location: Online group call 
    
    Attendees: All members 

    agenda items: 1.release of basic authentication functions 
                  2. exchange information of progression rate 

    meeting outcome: Haowei has completed the basic authentication functions such as login, log out, so that others can start writing their functions and import these basic functions 

##  Tenth meeting 

    Meeting purpose: group coding and exchange information about progression 

    Data and time: 20/10 2pm 
    
    location: CSE lab 
    
    Attendees: All members 

    agenda items: 1. Discuss about the acceptance criteria for user stories written in previous iteration. 
                  2. After the functions with priority are completed(such as login/channel create/userinfo), what?s the plan for next stage 

    meeting outcome: 
    A fixed structure and idea for acceptance criteria is created and the work responsibilities are distributed for each member. 
    Haowei - focusing on difficult functions and adjusting the data structure 
    Jinning, Haokai - pair programming and continues previous work 
    Yifei - editing test on the completed functions 
    (note: the responsible members are mainly focusing on collecting all the thought from other members and write them in words. All members are precipitating in discussions about all the work) 

##  Eleventh meeting 
    
    Meeting purpose: Discuss about the front-end 

    Data and time: 22/10 4pm 

    location: CSE lab 

    Attendees: All members 

    agenda items: 1.Discuss the method to display functions on the front-end 

    meeting outcome: We had a few attempts on the front-end provided by the course but fails. We decide to ask help from help session and come back after. 

##  Twelfth meeting 

    Meeting purpose: Completion the entire coding and start to debug/test/documentation work. 

    Data and time: 24/10 8pm 

    location: CSE lab 

    Attendees: All members 

    agenda items: 1. aggregating all the functions as a whole 
                  2. arrange the work for each member in the last stage 

    meeting outcome: We?ve decide the responsibility for each member, and people in charge will be taking the leadership of their work. 
 
    Haowei - Debug and ensure the verification of our program 
    Jinning, Haokai - review and edit all the test written in iteration 1 
    Yifei - Check the code coverage and start the documentation work 

##  Thirteenth meeting 

    Meeting purpose: Solve the problem occur in message_remove and standup function. 

    Data and time: 25/10 8pm 

    location: Online call 

    Attendees: All members 

    agenda items: 1. Discuss the bugs and conflicts in these two functions and debug. 

    meeting outcome: the problem is efficiently solved after we reedit our data structure. 

##  Fourteenth meeting 
    
    Meeting purpose: Last checking before submission 
    
    Data and time: 26/10 4pm 
    
    location: CSE lab 
    
    Attendees: All members 

    agenda items: 1. All the documentation work are posted in right format 
                  2. program is bug-less and runnable 
                  3. All the tests are working and provide good coverage 

    meeting outcome: All the works are perfectly done and we eventually finished our work! 
    (The listing meetings are only the major physical meeting, in fact a active exchange of information have been lasted in the project group chat. As well as, some of the member have performed a series of positive communications personally which eventually result as great improvement in our test code and documentation work.) 
# 2. Demonstration of appropriate use of agile practices to work effectively as a team.

## Standups

    For our team, we have a online group chatting, we usually don?t actually stand up for "Standups" but we update our progress very frequently. 

    Firstly, we always let others know as soon as we have done any works and we post them in the group chat. We also tell others what problems we have encountered and what we are going to do after we finish the current work. 
    Furthermore, we have a common habit for group coding, we always code together in CSE lab at night. As soon as a problem is raised, we try to solve it by individual, if it falls, then we group up and solve it collectively. The other benefit for group coding is we could always check other?s progression when they just sit next to us. So we won't have any clash in work and coordinating everything well. 

## Sprints/iterations
    
    Since our project is designed to be done in 3 iterations, it is compulsory to follow the instructions. However, this experience is actually inspiring for all of us. It is our first time to work on an iteration-based projects and it places us in the real circumstance that how a project is started and worked by multiple people. 

    It also helps us to arrange our work and time reasonably, so we can divides our work into multiple stages and parts. During a certain part, we are just focusing on the goal we set up and we don't get influenced or overthink by other factors. The iterations-oriented mode is refreshing to us and it really assist our completion of the entire project. 

## Task-boards
    
    We didn't apply the task board function in GItlab since we've been contacting extremely frequent. However, we have written the acceptance criteria in early stage and it helps us with the function building. 

    It's also worth to notice, we always use our chatting record log and the highlighting functions as a task-board. In this way, every time when a group member check the recoding, they are able to review other member's progression as well as what's the priority at the moment. So that they could decide what to do next, debugging, writing now functions or testing other?s work. There is no doubt that the task-board methodology is absolutely great for team working, it maximise the interactions between team members, especially in our project. 

## Pair programming:

    We have been pair programming since iteration one, there are so many good things about pair programming. For us, sometime one person is hard to ?think outside of box? when problem occurs, so it may take forever for us to debug our own mistake but with thoughts from others, it make optimise our efficiency. In addition, when two people code together, they can take advantage from other's ideas. 

    In both way, pair programming can achieve ?1+1>2?, for most of code we?ve written, we have applied pair programming.It increase our efficiency by avoiding bugs and refining the code. 

## Test-Driven-Development

    It's also compulsory for us to write the tests before the functions. Although we find the test is not really runnable after we complete the functions, there are changes made in functions names, structures and other details. 

    Whereas, during the process for writing the test, we have developed a deep understanding about the test. Even we didn't write the function, we are aware what kinds of mistakes we should avoid. It stops us from making significant mistakes and makes the project more smooth. 

    Additionally, we can test the function directly by the test when we complete it and check which specific test it fails to pass. It saves lots of time for us to debug and edit the function rather than writing test after completion. 

    Working in a Test-Driven-Development mode is also a good strategy to increase the efficiency.

# 3. Consistent work towards the goal of a working backend.

    There are a lots of evidence proving our consistence of work in backend. 
    -More than 300 times commit in gitlab (Though we don't use gitlab frequently)
    -More than 1000 course-relevant messages in the project groups chat?s message log 
    -Attendance of most group member to the CSE lab in the late night 

    The most important evidence is that, we eventually complete the code(even we test it on front?end), they are perfectly runnable and they are well tested. 

# 4. Task board is always up to date and reflects ongoing work

    We didn?t use the task board in the gitlab but as I mentioned in the previous section, we leave the record in the gitlab commit, and we keep it up to data in our chatting group chat which basically follow the general pattern:
    -> design data structure
    -> complete basic functions(register, login?) 
    -> complete important functions(user_profile, channel_create..)
    -> complete other functions
    -> edit functions based on the acceptance criteria 
    -> edit test and ensure their coverage 
    -> complete all the documentation work 

    We are aware of the importance to keep task board up to date and we apply it in our group chat APP instead of gitlab so that we can check it every time we update our progression. 

# 5. demonstration that responsibilities were allocated across team member

    Haowei is taking the leadership throughout the project, since he has got a stronger programming background and he is responsible for designing the data structure, function structure and format. 

    Other 3 members are evenly working on different functions regarding Haowei's instructions and coordinate his work. Yifei is more focusing on testing and message functions, Jinning is responsible for channel functions and Haokai is working on user functions. 

# 6. Clear reflection on areas for improvement
 
    Generally, we have a great improvement in comparing with last iteration but we can do a better job if we start planning earlier. 

    Some time we fail to meet the short term target, we could improve our efficiency if we can execute our plan better. 

    Overall, we?ve done a good job this time, but if we can manage our time more efficient, we would have time time to adjust with front-end and refine our functions. We have been stuck in some silly bugs which is caused by spelling error if we could avoid these mistakes then we will be definitely more well-organised 

# 7. impression that team has worked together collaboratively

    The use of gitlab allows us to check each other?s code at any time and also interact with each other's thought. We were taking advantage of each other?s idea (Haowei's design for data structure). During our coding process, all the good thoughts are centralised, eventually the test code is a product of corporation. 

    Additionally, as we mentioned before the maximising individual?s advantaging, exchanging information all the time, regular team meeting, those factors are proving the collaborative teamwork. 

# 8. impression that team has processed in place to work through disagreements or tension

    Obviously, disagreements have exerted and bad atmosphere have been sparked by divergences. However, we always listen to each other and express our own idea logically. The major disagreement happen when Yifei suggests a change in the message dictionary list that element "if_remove" should be added in. But Haowei is not agreeing with that initially and thinks there is a better way to solve the problem.

    However, the conflict is soon solved after Haowei takes Yifei's suggestion. 

# 9.Impression that team had a thought out methodology for completing the iteration
    
    The greatest impression is from the process we write our remove function. Since we didn?t consider if_message_remove as a property to a message, so there is no way we can represent this in the functions. So that, we choose the optimal solution to add a new key in the message list dictionary and edit all the relevant functions and tests.

    The process, we find the problem and we state our idea for each member and then we choose the optimal solution and apply the changes. The entire methodology is very useful for any arises of problems. 

    Moreover the thought is a smartest way to achieve our goal but brings the least side effects. That saves us plenty of time and minimised future bugs bring up by the edition of entire program. 
